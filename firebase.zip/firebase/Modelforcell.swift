//
//  Modelforcell.swift
//  firebase
//
//  Created by Walid Elharby on 7/29/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//

import Foundation
struct ChatMessages {

    var key :String
    var username :String
    var message :String
    var userid :String
}
