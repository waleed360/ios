//
//  Model.swift
//  firebase
//
//  Created by Walid Elharby on 7/23/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//

import Foundation
struct Rooms {
    var roomname :String
    var roomid :String
}
