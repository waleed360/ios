//
//  RoomsViewController.swift
//  firebase
//
//  Created by Walid Elharby on 7/22/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//

import UIKit
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase
class RoomsViewController: UIViewController , UITableViewDelegate,UITableViewDataSource{
    @IBOutlet weak var newroomnametextfield: UITextField!
    var roomarray = [Rooms]()
    @IBOutlet weak var roomstable: UITableView!

    
    func observe (){
        let referance = Database.database().reference()
        referance.child("Rooms").observe(.childAdded) { (snapshot) in
            print(snapshot)
            if let dataarray = snapshot.value as? [String : Any]{
                if let roomname = dataarray["roomname"] as? String{
                    let room = Rooms.init(roomname: roomname, roomid: snapshot.key)
                    self.roomarray.append(room)
                    self.roomstable.reloadData()
                }
                
            }
        }
    }
    @IBAction func didpresscreatenewroom(_ sender: UIButton) {
        
        guard let roomname = newroomnametextfield.text , roomname.isEmpty == false else{
         return
        }
        self.newroomnametextfield.text = ""

        let referance = Database.database().reference()
        let room = referance.child("Rooms").childByAutoId()
        let dataarray : [String:Any] = ["roomname":roomname]
        room.setValue(dataarray) { (error, resault) in
            if (error == nil){
                
            }
            
        }
        
        
        
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        roomarray.removeAll()

        if(Auth.auth().currentUser == nil){
            presentloginscreen()

        }else
        {
            
        }
        observe()
    }

    @IBAction func didpresslogout(_ sender: UIBarButtonItem) {
       try! Auth.auth().signOut()
        presentloginscreen()
    }
    func presentloginscreen()  {
        let formscreen = self.storyboard?.instantiateViewController(withIdentifier: "loginscreen") as!ViewController

        self.present(formscreen, animated: true, completion: nil)

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return roomarray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let roomname = self.roomarray[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "roomcell")!
        cell.textLabel?.text = roomname.roomname
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let selectedrow = roomarray[indexPath.row]
        let storyboard = self.storyboard?.instantiateViewController(withIdentifier: "chatroom") as! chatroomViewController
        storyboard.room = selectedrow
   self.navigationController?.pushViewController(storyboard, animated: true)    }
    
}
