//
//  collectionview.swift
//  firebase
//
//  Created by Walid Elharby on 7/21/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//
import UIKit
import Foundation
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase
extension ViewController :UICollectionViewDelegate,UICollectionViewDataSource , UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FormCell", for: indexPath)as! FormCell
        if (indexPath.row == 0) {
        cell.usernamecontainer.isHidden=true
            cell.actionbutton.setTitle("login", for: .normal)
            cell.slidebutton.setTitle("signup 👉", for: .normal)
            cell.slidebutton.addTarget(self, action: #selector(slidetosignup(_sender:)) , for: .touchUpInside)
            cell.actionbutton.addTarget(self, action: #selector(didpresssignin(_:)), for: .touchUpInside)

        }else if(indexPath.row==1){
            cell.usernamecontainer.isHidden=false
            cell.actionbutton.setTitle("signup", for: .normal)
            cell.slidebutton.setTitle("👈 sign in ", for: .normal)
            cell.slidebutton.addTarget(self, action: #selector(slidetosignin(_sender:)) , for: .touchUpInside)
            
            cell.actionbutton.addTarget(self, action: #selector(didpresssignup(_:)), for: .touchUpInside)

            
        }
        return cell
    
    }
    @objc func didpresssignup(_ sender:UIButton){
        let indexpath = IndexPath(row: 1, section: 0)

        let cell = self.collectionview.cellForItem(at: indexpath) as! FormCell
        guard  let email = cell.emailaddresstextfield.text , let password = cell.passwordtextfield.text else{
            return
        }
        Auth.auth().createUser(withEmail: email, password: password) { (resault, error) in
            if(error == nil){
                guard let userid = resault?.user.uid ,let usertext = cell.usernametextfield.text   else{
                    return
                }
                self.dismiss(animated: true, completion: nil)
 
                let referance = Database.database().reference()
                let user =  referance.child("users").child(userid)
                let dataarray:[String:Any] =  ["username":usertext]
                    user.setValue(dataarray)

            }else{
                self.dissplayerror(errortext: " email found")

                print(error)
            }
        }
        
    }
    @objc func didpresssignin(_ sender:UIButton){
        let indexpath = IndexPath(row: 0, section: 0)
        
        let cell = self.collectionview.cellForItem(at: indexpath) as! FormCell
        guard  let email = cell.emailaddresstextfield.text , let password = cell.passwordtextfield.text else{
            return
        }
        if (email.isEmpty == true || password.isEmpty == true){
            
            
            self.dissplayerror(errortext: "Wrong email or password111")

        }else{
        Auth.auth().signIn(withEmail: email, password: password) { (resault, error) in
            if(error == nil){
                self.dismiss(animated: true, completion: nil)
              print(resault?.user.uid)
            }
            else{
                print(error )
                self.dissplayerror(errortext: "Wrong email or password")
            }}}
            
        
        
        
        
        
        
    }
    
    
    func dissplayerror(errortext:String)  {
        let alert = UIAlertController.init(title: "Error", message: errortext, preferredStyle: .alert )
        let alertaction = UIAlertAction.init(title: "dissmis", style: .default, handler: nil)
        alert.addAction(alertaction)
        self.present(alert, animated: true, completion: nil)
    }
   @objc func slidetosignup( _sender :UIButton){
        let indexpath = IndexPath(row: 1, section: 0)
        self.collectionview.scrollToItem(at: indexpath, at: .centeredHorizontally, animated: true)
        
    }
    @objc func slidetosignin( _sender :UIButton){
        let indexpath = IndexPath(row: 0, section: 0)
        self.collectionview.scrollToItem(at: indexpath, at: .centeredHorizontally, animated: true)
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
     return collectionView.frame.size
        
    }
}
