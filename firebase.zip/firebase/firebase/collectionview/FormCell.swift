//
//  FormCell.swift
//  firebase
//
//  Created by Walid Elharby on 7/22/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//

import UIKit

class FormCell: UICollectionViewCell {
    
    @IBOutlet weak var actionbutton: UIButton!
    @IBOutlet weak var usernamecontainer: UIView!
    
    @IBOutlet weak var emailaddresstextfield: UITextField!
    @IBOutlet weak var passwordtextfield: UITextField!
    @IBOutlet weak var slidebutton: UIButton!
    @IBOutlet weak var usernametextfield: UITextField!
}
