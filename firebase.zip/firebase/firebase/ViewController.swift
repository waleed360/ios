//
//  ViewController.swift
//  firebase
//
//  Created by Walid Elharby on 7/21/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//

import UIKit
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase
class ViewController: UIViewController {
  
    

    @IBOutlet weak var collectionview: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //// test firebase
//        let referance = Database.database().reference()
//        let room = referance.child("chatroom")
//        room.setValue("Hello Firebase")
        // Do any additional setup after loading the view.
    
    }


}





