//
//  chatroomViewController.swift
//  firebase
//
//  Created by Walid Elharby on 7/28/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//

import UIKit
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase

class chatroomViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{
    
    var messagearray = [ChatMessages]()
    @IBOutlet weak var chattableview: UITableView!
    @IBOutlet weak var chatmessagetextfield: UITextField!
    
    var room :Rooms?
    override func viewDidLoad() {
        super.viewDidLoad()
    observemessage()
        chattableview.separatorStyle = .none
        chattableview.allowsSelection = false
        // Do any additional setup after loading the view.
    }
    
    func observemessage(){
        guard let roomid = self.room?.roomid else{
            return
        }
        
        let database = Database.database().reference()
        database.child("Rooms").child(roomid).child("Message").observe(.childAdded) { (snapshot) in
            
        print(snapshot)
            if let array = snapshot.value as? [String : Any]{
                guard let sendername = array["Sendername"] as?String, let messagecontent = array["messagecontent"] as?String , let uid = array["Senderid"] as?String else{
                    return
                }
                let messages = ChatMessages.init(key: snapshot.key, username: sendername, message: messagecontent, userid: uid)
                print(uid)
                self.messagearray.append(messages)
                self.chattableview.reloadData()
                


            }

        }

    }
    func getusernamr (id : String, complition : @escaping (_ username :String?)->()){
        
        
        
        let database = Database.database().reference()
        let user = database.child("users").child(id)
        
        user.child("username").observeSingleEvent(of: .value) { (snapshot) in
            if let username = snapshot.value as?String{
                complition(username)
            }else{
                
                complition(nil)
            }
        }}
    func sendmeesage (message :String , complition : @escaping (_ issuccess : Bool)-> ()){
        guard   let uid = Auth.auth().currentUser?.uid else{
            return
        }
        let database = Database.database().reference()

        getusernamr(id: uid) { (usernamee) in
    
            if let username = usernamee {
                let arrar :[String : Any] = ["Sendername" : username , "messagecontent" : message , "Senderid" : uid ]
                if let userid = self.room?.roomid as? String{
                    let room = database.child("Rooms").child(userid)
                    room.child("Message").childByAutoId().setValue(arrar, withCompletionBlock: { (error, resualt) in
                        if (error == nil){

                    complition(true)
                        }
                    })
                    
                }
            }
        }
        
    }
    
    @IBAction func didclicksend(_ sender: UIButton) {
        guard let message = chatmessagetextfield.text , message.isEmpty == false
 else {
            return
        }
        sendmeesage(message: message) { (bool) in
            if (bool == true){
                self.chatmessagetextfield.text = ""
                print("message send")
            }
            else{
                print("message not sent")
            }
        }
    
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messagearray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let message = self.messagearray[indexPath.row]
        let cell =  chattableview.dequeueReusableCell(withIdentifier: "chatcell") as! Chatcell
//        cell.sendernametextfield.text = message.username
//        cell.messagetextview.text = message.message
        cell.setmessagedata(message: message)
        print(messagearray[indexPath.row].userid)
        print(Auth.auth().currentUser?.uid)
        if (message.userid == Auth.auth().currentUser?.uid ){
            
            
            cell.setpubbletype(type: .outgoing)}
        else{
            cell.setpubbletype(type: .incoming)}
        return cell

        }
    

}
