//
//  Chatcell.swift
//  firebase
//
//  Created by Walid Elharby on 7/29/19.
//  Copyright © 2019 Walid Elharby. All rights reserved.
//

import UIKit

class Chatcell: UITableViewCell {

    @IBOutlet weak var stackchat: UIStackView!
    enum bubbleType {
        case incoming
        case outgoing
    }
    @IBOutlet weak var viewcintainer: UIView!
    @IBOutlet weak var messagetextview: UITextView!
    @IBOutlet weak var sendernametextfield: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        viewcintainer.layer.cornerRadius = 10
    }
    func setpubbletype(type : bubbleType){
        if(type == .incoming){
            stackchat.alignment = .leading
            viewcintainer.backgroundColor = #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
            messagetextview.textColor = .black

        }else if(type == .outgoing){
            
            stackchat.alignment = .trailing 
            viewcintainer.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
            messagetextview.textColor = .white

        }
    }
    func setmessagedata(message : ChatMessages){
        sendernametextfield.text = message.username
        messagetextview.text = message.message
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
